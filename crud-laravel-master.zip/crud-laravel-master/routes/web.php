<?php

use App\Http\Controllers\ProductsController;
use App\Http\Controllers\SetorController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\TicketController;
use Illuminate\Routing\RouteGroup;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::redirect('/', '/tickets');



Route::get('/login', [LoginController::class, 'login'])->name('login.index')->middleware('guest');
Route::post('/login', [LoginController::class, 'auth'])->name('login.auth');


Route::middleware('auth')->group(function () {

    Route::get('/tickets', [TicketController::class, 'index'])->name('ticket.index');

    Route::get('/logout', [LoginController::class, 'logout'])->name('login.logout');

    Route::get('/products/new', [ProductsController::class, 'create']);
    Route::post('/products/new', [ProductsController::class, 'store'])->name('register_product');
    Route::get('/products/show/{id}', [ProductsController::class, 'show']);
    Route::get('/products/', [ProductsController::class, 'index']);
    Route::get('/products/edit/{id}', [ProductsController::class, 'edit']);
    Route::put('/products/update/{id}', [ProductsController::class, 'update'])->name('update_product');
    Route::get('/products/delete/{id}', [ProductsController::class, 'delete']);
    Route::delete('/products/delete/{id}', [ProductsController::class, 'destroy'])->name('delete_product');

    Route::get('/setor/cadastrar', [SetorController::class, 'create'])->name('cadastrar.setor');
    Route::post('/setor/cadastrar', [SetorController::class, 'store'])->name('register_setor');
    Route::get('/setor/show/{id}', [SetorController::class, 'show']);
    Route::get('/setor/', [SetorController::class, 'index'])->name('setor.index');
    Route::get('/setor/edit/{id}', [SetorController::class, 'edit']);
    Route::put('/setor/update/{id}', [SetorController::class, 'update'])->name('update_setor');
    Route::get('/setor/delete/{id}', [SetorController::class, 'delete']);
    Route::delete('/setor/delete/{id}', [SetorController::class, 'destroy'])->name('delete_setor');
});
