<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    public function login()
    {
        return view('welcome');
    }

    public function auth(Request $request)
    {
        $this->validate($request,[
            'email' => 'required',
            'password' => 'required'
        ],[
            'email.required' => 'E-mail é obrigatório.',
            'password.required' => 'Senha é obrigatória.',
        ]);

        if(Auth::attempt(['email' => $request->email, 'password' => $request->password])){
   
        }
        else {
            return redirect()->back()->with('danger', 'E-mail ou Senha inválida');
        }
    }

    public function index()
    {
        $users = User::all();

        return view('user.index', compact('users'));
    }

    public function create()
    {
        return view('user.create');
    }

    public function store(Request $request)
    {
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'ramal' => $request->ramal,
            'tipo' => $request->tipo,
            'setores_id' => $request->setores_id,
        ]);

        return view('user.create');
    }

    public function show($id)
    {

        $user = User::findOrFail($id);
        return view('user.show', ['user' => $user]);
    }

    public function edit($id)
    {
        $user = User::findOrFail($id);
        return view('user.edit', ['user' => $user]);
    }

    public function update(Request $request, $id)
    {

        $user = User::findOrFail($id);

        $user->update([
            'name' => $request->name,
        ]);

        return view('user.edit', ['user' => $user]);
    }

    public function delete($id)
    {
        $user = User::findOrFail($id);
        return view('user.delete', ['user' => $user]);
    }

    public function destroy($id)
    {

        /*$userPossuiUsuarios = User::where('users_id', $id)->exists();

        if ($userPossuiUsuarios) {
            return redirect()->route('user.index')->with('error', 'Esse user não pode ser excluido, pois existem usuários nesse user.');
        }*/

        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('user.index')->with('mensagem', 'Sucesso ao excluir!');
    }

    public function cancel()
    {
        return view('user.index');
    }
}