<?php

namespace App\Http\Controllers;

use App\Models\Setor;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Http\Request;


class SetorController extends Controller
{

    public function index()
    {
        $setores = Setor::all();

        return view('setor.index', compact('setores'));
    }

    public function create()
    {

        return view('setor.create');
    }

    public function store(Request $request)
    {
        Setor::create([
            'name' => $request->name,
        ]);

        return view('setor.create');
    }

    public function show($id)
    {

        $setor = Setor::findOrFail($id);
        return view('setor.show', ['setor' => $setor]);
    }

    public function edit($id)
    {
        $setor = Setor::findOrFail($id);
        return view('setor.edit', ['setor' => $setor]);
    }

    public function update(Request $request, $id)
    {

        $setor = Setor::findOrFail($id);

        $setor->update([
            'name' => $request->name,
        ]);

        return view('setor.edit', ['setor' => $setor]);
    }

    public function delete($id)
    {
        $setor = Setor::findOrFail($id);
        return view('setor.delete', ['setor' => $setor]);
    }

    public function destroy($id)
    {

        $setorPossuiUsuarios = User::where('setores_id', $id)->exists();

        if ($setorPossuiUsuarios) {
            return redirect()->route('setor.index')->with('error', 'Esse setor não pode ser excluido, pois existem usuários nesse setor.');
        }

        $setor = Setor::findOrFail($id);
        $setor->delete();

        return redirect()->route('setor.index')->with('mensagem', 'Sucesso ao excluir!');
    }

    public function cancel()
    {
        return view('setor.index');
    }
}
