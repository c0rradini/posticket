

<?php $__env->startSection('title', 'Setores'); ?>

<?php $__env->startSection('page'); ?>
<div class="container" style="margin-top: 15px;margin-bottom: 15px;">
    <div class="row">
        <div class="col-md-12" style="margin-top: 15px;">
            <p style="margin-bottom: 5px;font-size: 32px;font-weight: bold;">Lista de Setores</p>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <a class="btn" role="button" href="<?php echo e(route('cadastrar.setor')); ?>" style="background: #097ec1;color: rgb(255,255,255);">Cadastrar Novo Setor</a>
        </div>
    </div>
    <div class="row">
        <div class="col" style="margin-top: 15px;">
            <p style="margin-bottom: 5px;margin-top: 5px;">Lista de setores já cadastrados:</p>
           
                
                <div class="table-responsive">

                <table id="tabela" class="table table-striped display">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th class="text-end">Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $setores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($setor->id); ?></td>
                            <td><?php echo e($setor->name); ?></td>
                            <td class="text-end">
                                <a class="btn btn-success m-1" role="button" href="<?php echo e(route('edit.setor', $setor->id )); ?> ">Editar</a>
                                <a class="btn btn-danger m-1" role="button" href="<?php echo e(route('delete.setor', $setor->id )); ?>">Excluir</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#tabela').DataTable({
            "responsive": true,
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.12.1/i18n/pt-BR.json"
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-laravel-master\resources\views/setor/index.blade.php ENDPATH**/ ?>