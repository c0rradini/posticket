<?php $__env->startSection('title', 'Editar Setor'); ?>

<?php $__env->startSection('page'); ?>
<div class="container" style="margin-top: 15px;margin-bottom: 15px;">
    <div class="row">
        <div class="col-md-12" style="margin-top: 15px;">
            <p style="margin-bottom: 5px;font-size: 32px;font-weight: bold;">Cadastro de Setor</p>
        </div>
    </div>

    <form action="<?php echo e(route('atualiza.setor', ['id'=>$setor->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-6" style="margin-top: 15px;">
                <p style="margin-bottom: 5px;margin-top: 5px;">Editar Setor*</p>
                <input class="bg-light border rounded shadow-sm p-2" type="text" id="name" name="name" placeholder="Nome do Setor" value=" <?php echo e(old('name', $setor->name)); ?>" style="width: 100%;">
                <button class="btn m-1 mt-3" type="submit" style="background: #097ec1;color: rgb(255,255,255);">Editar</button>
                <a class="btn m-1 mt-3" role="button" href="<?php echo e(route('setor.index')); ?>" style="background: #b1b1b1;color: rgb(255,255,255);">Voltar</a>
            </div>

            <div class="col-md-6" style="margin-top: 15px;">
                <p style="margin-bottom: 5px;margin-top: 5px;">Lista de setores já cadastrados:</p>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nome</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = App\Models\Setor::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($setor->name); ?></td>
                                <td class="text-start">
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\posticket\resources\views/setor/edit.blade.php ENDPATH**/ ?>