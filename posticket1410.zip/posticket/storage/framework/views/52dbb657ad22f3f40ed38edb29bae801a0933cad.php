<?php $__env->startSection('title', 'Cadastrar Usuário'); ?>

<?php $__env->startSection('page'); ?>
<div class="container" style="margin-top: 15px;margin-bottom: 15px;">
    <div class="row">
        <div class="col-md-12" style="margin-top: 15px;">
            <p style="font-size: 32px;font-weight: bold;">Cadastro de Usuário</p>
        </div>
    </div>
    <form action="<?php echo e(route('register_user')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6" style="margin-top: 10px;">
                <p style="margin-bottom: 5px;margin-top: 5px;">Nome</p>
                <input required class="form-control bg-light border rounded shadow-sm p-2 mb-4" type="text" id="name" name="name" style="width: 100%;">
                <p style="margin-bottom: 5px;margin-top: 5px;">Email</p>
                <input required class="form-control bg-light border rounded shadow-sm p-2 mb-4" type="email" id="email" name="email" style="width: 100%;" placeholder="example@posticket.com">
                <p style="margin-bottom: 5px;margin-top: 5px;">Senha</p>
                <input required class="bg-light border rounded shadow-sm p-2 mb-4" type="password" id="password" name="password" style="width: 100%;" placeholder="••••••••••">
            </div>
            <div class="col-md-6" style="margin-top: 10px;">
                <p style="margin-bottom: 5px;margin-top: 5px;">Ramal</p>
                <input required class="form-control bg-light border rounded shadow-sm p-2 mb-4 w-5" type="text" id="ramal" name="ramal" style="width: 100%;">
                <p style="margin-bottom: 5px;margin-top: 5px;">Setor</p>

                <select name="setores_id" class="form-control bg-light border rounded shadow-sm p-2 mb-4" required="ON">
                    <option value="">Selecione o Setor...</option>
                    <?php $__currentLoopData = App\Models\Setor::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($setor->id); ?>" class="text-start"><?php echo e($setor->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    F
                </select>

                <p style="margin-bottom: 5px;margin-top: 5px;">Tipo</p>
                <select required class="form-control bg-light border rounded shadow-sm p-2 mb-4" id="tipo" name="tipo" style="width: 100%;">
                    <option value="undefined" selected>Selecione o Tipo de pessoa...</option>
                    <option value="tec">Técnico</option>
                    <option value="user">Usuário</option>
                </select>
            </div>
        </div>
</div>
<div class="container" style="margin-top:10px">
    <div class="row">
        <div class="col">
            <button class="btn m-1 mt-3" type="submit" style="background: #097ec1;color: rgb(255,255,255);">Concluir</button>
            <a class="btn m-1 mt-3" role="button" href="<?php echo e(route('user.index')); ?>" style="background: #b1b1b1;color: rgb(255,255,255);;">Voltar</a>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\posticket\resources\views/user/create.blade.php ENDPATH**/ ?>