

<?php $__env->startSection('title', 'Setores'); ?>

<?php $__env->startSection('page'); ?>
<div class="container" style="margin-top: 15px;margin-bottom: 10px;">

    <div class="row">
        <div class="col-md-12" style="margin-top: 10px;">
            <p style="margin-bottom: 5px;font-size: 32px;font-weight: bold;">Lista de Setores</p>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <a class="btn" role="button" href="<?php echo e(route('cadastrar.setor')); ?>" style="background: #097ec1;color: rgb(255,255,255);">Cadastrar Novo Setor</a>
        </div>
    </div>

    <?php if(session('mensagem')): ?>
    <div id="fadeOut" class="fadeOut alert alert-success mt-3">
        <p><?php echo e(session('mensagem')); ?></p>
    </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div id="fadeOut" class="fadeOut alert alert-danger mt-3">
        <p><?php echo e(session('error')); ?></p>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col" style="margin-top: 10px;">
            <p style="margin-bottom: 5px;margin-top: 5px;">Lista de setores já cadastrados:</p>

            <div class="table-responsive">

                <table id="tabela" class="table table-striped display">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th class="text-end">Ação</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php $__currentLoopData = $setores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($setor->id); ?></td>
                            <td><?php echo e($setor->name); ?></td>

                            <td class="text-end">
                                <a class="btn btn-success m-1" role="button" href="<?php echo e(route('edit.setor', $setor->id )); ?> ">Editar</a>

                                <div class="modal fade" role="dialog" tabindex="-1" id="modal-delete-<?php echo e($setor->id); ?>">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" style="margin-right: 31px;">Deseja realmente excluir?</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body text-start">
                                                <span>ID: <?php echo e($setor->id); ?></span></br>
                                                <span>Nome: <?php echo e($setor->name); ?></span>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-center">
                                                <button class="btn btn-primary text-light" type="button" data-bs-dismiss="modal">Voltar</button>
                                                <form action="<?php echo e(route('destroy.setor', $setor->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-danger">Excluir</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <button class="btn btn-danger m-1" type="button" data-bs-target="#modal-delete-<?php echo e($setor->id); ?>" data-bs-toggle="modal">Excluir</a>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#tabela').DataTable({
            "responsive": true,
            "language": {
                "url": "https://cdn.datatables.net/plug-ins/1.12.1/i18n/pt-BR.json"
            }
        });
    });
</script>

<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            $("#fadeOut").fadeOut().transition - duration('1000');
        }, 2000);
    }, true);
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\posticket\resources\views/setor/index.blade.php ENDPATH**/ ?>