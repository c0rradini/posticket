@extends('setor.index')

@section('table')
<div class="table-responsive">

    <table id="tabela" class="table table-striped display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th class="text-end">Ação</th>
            </tr>
        </thead>
        <tbody>
            @foreach($setores as $setor)
            <tr>
                <td>{{$setor->id}}</td>
                <td>{{$setor->name}}</td>
                <td class="text-end">
                    <button class="btn btn-success" type="button" style="margin: 5px;">Editar</button>
                    <button class="btn btn-danger" type="button" style="margin: 5px;">Excluir</button>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection