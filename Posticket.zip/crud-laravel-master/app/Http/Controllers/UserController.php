<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;



class UserController extends Controller
{

    public function login()
    {
        return view('welcome');
    }

    public function auth(Request $request)
    {
        $this->validate($request,[
            'email' => 'required',
            'password' => 'required'
        ],[
            'email.required' => 'E-mail é obrigatório.',
            'password.required' => 'Senha é obrigatória.',
        ]);

        if(Auth::attempt(['email' => $request->email, 'password' => $request->password])){
          dd('logou');     
        }
        else {
            return redirect()->back()->with('danger', 'E-mail ou Senha inválida');
        }
    }
}
