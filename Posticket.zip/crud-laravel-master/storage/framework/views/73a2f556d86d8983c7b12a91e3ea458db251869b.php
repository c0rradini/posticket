

<?php $__env->startSection('table'); ?>
<table id="tabela" class="table table-striped display">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th class="text-end">Ação</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $setores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($setor->id); ?></td>
            <td><?php echo e($setor->name); ?></td>
            <td class="text-end">
                <button class="btn btn-success" type="button" style="margin: 5px;">Editar</button>
                <button class="btn btn-danger" type="button" style="margin: 5px;">Excluir</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\crud-laravel-master\resources\views/setor/table.blade.php ENDPATH**/ ?>